const items = document.querySelectorAll(".dropdown__item");
const values = document.querySelectorAll(".dropdown__value");

values.forEach((value) => value.addEventListener("click", open));

function open(event) {
  const list = event.target.nextElementSibling;
  list.classList.add("dropdown__list_active");
}

items.forEach((element) => {
  element.addEventListener("click", choose);
});

function choose(event) {
  const div = event.target.parentElement.parentElement;
  const value = div.querySelector(".dropdown__value");
  const list = event.target.parentElement;
  console.log(event.target);
  const text = event.target.textContent;
  event.preventDefault();

  list.classList.remove("dropdown__list_active");
  value.textContent = text;
}
